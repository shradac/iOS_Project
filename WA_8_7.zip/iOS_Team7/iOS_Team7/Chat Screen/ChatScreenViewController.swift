//
//  ChatScreenViewController.swift
//  iOS_Team7
//
//  Created by Vasu Agarwal on 3/31/24.
//
import UIKit
import FirebaseFirestore
import FirebaseAuth

class ChatScreenViewController: UIViewController {
    // Declare properties
    var chatView: ChatScreenView!
    var messages: [ChatMessage] = []
    var chatID: String = "" // You need to set this with the specific chat ID
    var loggedInUsr: String = ""
    
    // Firestore listener
    var listener: ListenerRegistration?
    
    init(chatID: String) {
       self.chatID = chatID
       self.loggedInUsr = Auth.auth().currentUser?.uid ?? ""
        print(self.loggedInUsr)
       super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
       fatalError("init(coder:) has not been implemented")
    }
    
    override func loadView() {
        chatView = ChatScreenView()
        view = chatView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Chat"
        
        let tapRecognizer = UITapGestureRecognizer(target: self, action: #selector(hideKeyboardOnTap))
            tapRecognizer.cancelsTouchesInView = false
            view.addGestureRecognizer(tapRecognizer)
        
        chatView.tableView.dataSource = self
        chatView.tableView.delegate = self
        
        // Fetch chat messages
        fetchMessages()
        
        
        //attach listener for send btn
        chatView.sendButton.addTarget(self, action: #selector(sendClicked), for: .touchUpInside)
        
        // Listen for new messages
        listenForMessages()
    }
    
    @objc func hideKeyboardOnTap(){
        //MARK: removing the keyboard from screen...
        view.endEditing(true)
    }
    
    deinit {
        // Remove Firestore listener when the view controller is deallocated
        listener?.remove()
    }
    
    @objc func sendClicked() {
        
        if let uwText = chatView.messageTextField.text {
            Model().sendMessage(text: uwText, chatId: chatID, senderId: self.loggedInUsr) { error in
                if let error = error {
                    print("Failed to send welcome message to all users: \(error.localizedDescription)")
                }
                self.chatView.messageTextField.text = ""
            }
        }
        
    }
    
    func fetchMessages() {
        print("In fetch msg")
        Model().fetchMessages(for: chatID) { [weak self] (messages, error) in
            guard let self = self else { return }
            if let error = error {
                print("Error fetching messages: \(error.localizedDescription)")
                return
            }
            self.messages = messages ?? []
            self.chatView.tableView.reloadData()
        }
    }
    
    func listenForMessages() {
        listener = Model().listenForMessages(in: chatID) { [weak self] (newMessages, error) in
            guard let self = self else { return }
            if let error = error {
                print("Error listening for messages: \(error.localizedDescription)")
                return
            }
            self.messages = newMessages/* + self.messages*/
            self.chatView.tableView.reloadData()
        }
    }
}

extension ChatScreenViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ChatCell", for: indexPath) as! ChatTableViewCell
        let message = messages[indexPath.row]
        
        // Determine message type (incoming or outgoing) based on senderId
        let messageType: MessageType = (message.senderId == Auth.auth().currentUser?.uid) ? .outgoing : .incoming
        
        // Configure cell with message data
        cell.configure(with: message.text, senderName: "", timestamp: message.timestamp.timeIntervalSince1970, type: messageType)
        
        return cell
    }
}
